// Name: Maggie Babson
// Project: Chada Tech Clocks
// Course: CS-210
// Description: 12 hr/ 24 hr time conversion

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class Clock {
protected:
    int hours, minutes, seconds;
public:
    Clock(int h, int m, int s) : hours(h), minutes(m), seconds(s) {}
    void addHour() { hours = (hours + 1) % 24; }
    void addMinute() { minutes = (minutes + 1) % 60; if (minutes == 0) addHour(); }
    void addSecond() { 
        if (seconds == 59) {
            seconds = 0;
            addMinute();
        } else {
            seconds++;
        }
    }
    virtual void displayTime() const = 0;  // Pure virtual function
};

class Clock12 : public Clock {
public:
    Clock12(int h, int m, int s) : Clock(h, m, s) {}
    void displayTime() const override {
        int displayHours = (hours % 12 == 0) ? 12 : hours % 12;
        string period = (hours < 12) ? "AM" : "PM";
        cout << "12-Hour Clock: " << setfill('0') << setw(2) << displayHours << ":"
             << setw(2) << minutes << ":" << setw(2) << seconds << " " << period << endl;
    }
};

class Clock24 : public Clock {
public:
    Clock24(int h, int m, int s) : Clock(h, m, s) {}
    void displayTime() const override {
        cout << "24-Hour Clock: " << setfill('0') << setw(2) << hours << ":"
             << setw(2) << minutes << ":" << setw(2) << seconds << endl;
    }
};

string twoDigitString(unsigned int n) {
    return (n < 10 ? "0" : "") + to_string(n);
}

string nCharString(size_t n, char c) {
    return string(n, c);
}

string formatTime24(unsigned int h, unsigned int m, unsigned int s) {
    return twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s);
}

string formatTime12(unsigned int h, unsigned int m, unsigned int s) {
    int displayHours = (h % 12 == 0) ? 12 : h % 12;
    string period = (h < 12) ? " A M" : " P M";
    return twoDigitString(displayHours) + ":" + twoDigitString(m) + ":" + twoDigitString(s) + period;
}

void displayMenu() {
    cout << "\nMenu:\n"
         << "1 - Add One Hour\n"
         << "2 - Add One Minute\n"
         << "3 - Add One Second\n"
         << "4 - Exit\n"
         << "Enter your time: ";
}

void displayClocks(unsigned int h, unsigned int m, unsigned int s) {
    cout << nCharString(27, '*') << " " << nCharString(27, '*') << endl;
    cout << "* 12-HOUR CLOCK *" << " " << "* 24-HOUR CLOCK *" << endl;
    cout << "* " << formatTime12(h, m, s) << " * "
         << "* " << formatTime24(h, m, s) << " *" << endl;
    cout << nCharString(27, '*') << " " << nCharString(27, '*') << endl;
    cout << endl;
}

void printMenu(char *strings[], unsigned int numStrings, unsigned char width) {
    cout << nCharString(width, '*') << endl;
    for (unsigned int i = 0; i < numStrings; ++i) {
        cout << "* " << i + 1 << " - " << strings[i] << " "
             << nCharString(width - (6 + to_string(i + 1).length() + string(strings[i]).length()), ' ')
             << "*" << endl;
        if (i < numStrings - 1) {
            cout << endl;
        }
    }
    cout << nCharString(width, '*') << endl;
}

unsigned int getMenuChoice(unsigned int maxChoice) {
    unsigned int choice;
    do {
        cin >> choice;
    } while (choice < 1 || choice > maxChoice);
    return choice;
}

int main() {
    Clock12 clock12(12, 0, 0);
    Clock24 clock24(12, 0, 0);
    
    int choice;
    do {
        clock12.displayTime();
        clock24.displayTime();
        displayMenu();
        choice = getMenuChoice(4);

        switch (choice) {
            case 1: clock12.addHour(); clock24.addHour(); break;
            case 2: clock12.addMinute(); clock24.addMinute(); break;
            case 3: clock12.addSecond(); clock24.addSecond(); break;
            case 4: cout << "Exiting program...\n"; break;
            default: cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 4);
    
    return 0;
}
